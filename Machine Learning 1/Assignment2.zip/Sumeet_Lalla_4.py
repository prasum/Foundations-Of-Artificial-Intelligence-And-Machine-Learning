# Name : Sumeet Lalla
# Centre : Bangalore

import pandas as pd
import numpy as np
import math
import operator
 
def euclideanDistance(instance1, instance2, length):
	distance = 0
	for x in range(length):
		distance += pow((instance1[x] - instance2[x]), 2)
	return math.sqrt(distance)
 
def getNeighbors(trainingSet, testInstance, k):
	distances = []
	length = len(testInstance)-1
	for x in range(len(trainingSet)):
		dist = euclideanDistance(testInstance, trainingSet[x], length)
		distances.append((trainingSet[x], dist))
	distances.sort(key=operator.itemgetter(1))
	neighbors = []
	for x in range(k):
		neighbors.append(distances[x][0])
	return neighbors
 
def getResponse(neighbors):
	classVotes = {}
	for x in range(len(neighbors)):
		response = neighbors[x][-1]
		if response in classVotes:
			classVotes[response] += 1
		else:
			classVotes[response] = 1
	sortedVotes = sorted(classVotes.items(), key=operator.itemgetter(1), reverse=True)
	return sortedVotes[0][0]
 
	
if __name__ == "__main__":
	
	training_set= pd.read_csv("data4.csv",header=None)
	test_set= pd.read_csv("test4.csv",header=None)
	testSet=np.asarray(test_set.values)
	training   = np.asarray(training_set.values)
	predictions=[]
	k = 5
	for x in range(test_set.shape[0]):
		test= np.asarray(test_set.iloc[x,:].values.reshape(-1))
		neighbors = getNeighbors(training, test, k)
		result = getResponse(neighbors)
		predictions.append(result)
	with open('Sumeet_Lalla_4.out', 'w') as f:
	    for i in range(len(predictions)):
		    f.write("%s" % predictions[i])
		    if(i!=len(predictions)-1):
			    f.write(' ')
	    f.close()	
	
	
