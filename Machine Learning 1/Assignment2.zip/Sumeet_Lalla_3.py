# Name : Sumeet Lalla
# Centre : Bangalore

import numpy as np
import pandas as pd
from collections import Counter, defaultdict
val=[0,1]
test_result=[]
def occurrences(list1):
	flag=False
	no_of_examples = len(list1)
	prob = dict(Counter(list1))
	for u in range(len(val)):
		if val[u] not in prob.keys():
			prob[val[u]]=0
			flag=True
	for key in prob.keys():
		if(flag):
			prob[key] = (prob[key]+1.0) / (float(no_of_examples)+2.0)
		else:
			prob[key] = (prob[key]) / (float(no_of_examples))
			
	flag=False	
	return prob

def naive_bayes(training, outcome, new_sample):
	classes     = np.unique(outcome)
	rows, cols  = np.shape(training)
	likelihoods = {}
	for cls in classes:
		likelihoods[cls] = defaultdict(list)
 
	class_probabilities = occurrences(outcome)
	for cls in classes:
		row_indices = np.where(outcome == cls)[0]
		subset      = training[row_indices, :]
		r, c        = np.shape(subset)
		for j in range(0,c):
			likelihoods[cls][j] += list(subset[:,j])
	for cls in classes:
		for j in range(0,cols):
			likelihoods[cls][j] = occurrences(likelihoods[cls][j])
 
	results = {}
	
	for cls in classes:
		class_probability = class_probabilities[cls]
	 
		for i in range(0,len(new_sample)):
			relative_values = likelihoods[cls][i]
			if new_sample[i] in relative_values.keys():
				class_probability *= relative_values[new_sample[i]]
				
			else:
				class_probability *= 0
			
		results[cls] = class_probability
	     
	max=0
	maxclass=-1
	for key in results.keys():
		if max<results[key]:
			max=results[key]
			maxclass=key
	test_result.append(maxclass)
 
if __name__ == "__main__":
    training_set= pd.read_csv("data3.csv",header=None)
    test_set= pd.read_csv("test3.csv",header=None)
    training   = np.asarray(training_set.iloc[:,:-1].values)
    outcome    = np.asarray(training_set.iloc[:,-1].values)
    for y in range(test_set.shape[0]):
	    test= np.asarray(test_set.iloc[y,:].values.reshape(-1))
	    naive_bayes(training, outcome, test)
    with open('Sumeet_Lalla_3.out', 'w') as f:
	    for i in range(len(test_result)):
		    f.write("%s" % test_result[i])
		    if(i!=len(test_result)-1):
			    f.write(' ')
		
	
	    f.close()