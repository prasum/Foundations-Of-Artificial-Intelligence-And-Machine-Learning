#This code generates random data from Uniform Distribution and assigns labels.
#The data is a non-linear one with points inside a circle of fixed radius marked as -1 and outside as +1.
#We flip the labels of some data (here with 5% probability) to introduce some noise.
#You will be using Decision Tree and Naive Bayes Classifiers to classify the above generated data.


import numpy as np
import matplotlib.pyplot as plt
#Do all the necessary imports here
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score
from sklearn.model_selection import cross_val_score
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
import matplotlib.pyplot as plt

def generate_data():

	np.random.seed(123) #Set seed for reproducibility. Please do not change/remove this line.
	x = np.random.uniform(-1,1,(500,2)) #You may change the number of samples you wish to generate
	y=[]
	for i in range(x.shape[0]):
		y.append(np.sign(x[i][0]**2 + x[i][1]**2 - 0.5)) #Forming labels
	return x,y

def flip_labels(y):

	num = int(0.05 * len(y)) #5% of data to be flipped
	np.random.seed(123)
	changeind = np.random.choice(len(y),num,replace=False) #Sampling without replacement
	#For example, np.random.choice(5,3) = ([0,2,3]); first argument is the limit till which we intend to pick up elements, second is the number of elements to be sampled

	#Creating a copy of the array to modify
	yc=np.copy(y) # yc=y is a bad practice since it points to the same location and changing y or yc would change the other which won't be desired always
	#Flip labels -1 --> 1 and 1 --> -1
	for i in changeind:
		if yc[i]==-1.0:
			yc[i]=1.0
		else:
			yc[i]=-1.0

	return yc

#Fill up the below function
def train_test_dt(x,y):

	# Perform a k-fold cross validation using Decision Tree
	#Plot train and test accuracy with varying k (1<=k<=10)
	accuracy_trainscore=[]
	accuracy_testscore=[]
	accuracy_meantrainscore=[]
	accuracy_meantestscore=[]
	samples=[]
	
	for i in range(2,11):
		skfold = StratifiedKFold(n_splits=i, shuffle=True, random_state=1)
		for train_index, test_index in skfold.split(x,y):
			dt_gini = DecisionTreeClassifier(criterion = "gini", random_state = 100, max_depth = 3 , min_samples_leaf = 5)  # Prevent overfitting
			#print(train_index,test_index)
			x_train, x_test = x[train_index], x[test_index]
			y_train, y_test = y[train_index], y[test_index]
			model=dt_gini.fit(x_train,y_train)
			y_testpred=model.predict(x_test)
			y_trainpred=model.predict(x_train)
			accuracy_testscore.append(accuracy_score(y_test,y_testpred))
			accuracy_trainscore.append(accuracy_score(y_train,y_trainpred))
		samples.append(i)
		accuracy_meantrainscore.append((sum(accuracy_trainscore)/i))
		accuracy_meantestscore.append((sum(accuracy_testscore)/i))
		accuracy_trainscore=[]
		accuracy_testscore=[]
	print("Decision Tree Classifier Accuracy for training vs test set")
	for k in range(len(accuracy_meantrainscore)):
		print("After"+" "+str(k+2)+" "+"fold training set accuracy:"+str(accuracy_meantrainscore[k]))
		print("After"+" "+str(k+2)+" "+"fold test set accuracy:"+str(accuracy_meantestscore[k]))
	#print(accuracy_meantrainscore,accuracy_meantestscore)
	plt.plot(samples,accuracy_meantrainscore,'bo-',label='Train Accuracy')
	plt.plot(samples,accuracy_meantestscore,'ro-',label='Test Accuracy')
	plt.xticks(fontsize=10)
	plt.yticks(fontsize=10)
	plt.xlabel('K Value during Cross Fold',fontsize=15)
	plt.ylabel('Mean Accuracy',fontsize=15)
	plt.legend(fontsize=15)
	plt.title('K vs Train/Test Accuracy For DecisionTreeClassifier',fontsize=15)
	axes = plt.gca()
	axes.set_ylim([0.7,0.9])
	plt.show()
	#cv_results = cross_val_score(model, x, y, cv=10, scoring='accuracy')
	#print(cv_results)
	

#Fill up the velow function
def train_test_nb(x,y):
	accuracy_trainscore=[]
	accuracy_testscore=[]
	accuracy_meantrainscore=[]
	accuracy_meantestscore=[]
	samples=[]
	# Perform a k-fold cross validation using Naive Bayes
	#Plot train and test accuracy with varying k (1<=k<=10)
	#nb = GaussianNB()
	
	for i in range(2,11):
		skfold = StratifiedKFold(n_splits=i, shuffle=True, random_state=1)
		for train_index, test_index in skfold.split(x,y):
			nb = GaussianNB()
			#print(train_index,test_index)
			x_train, x_test = x[train_index], x[test_index]
			y_train, y_test = y[train_index], y[test_index]
			model=nb.fit(x_train,y_train)
			y_testpred=model.predict(x_test)
			y_trainpred=model.predict(x_train)
			accuracy_testscore.append(accuracy_score(y_test,y_testpred))
			accuracy_trainscore.append(accuracy_score(y_train,y_trainpred))
			
		samples.append(i)
		accuracy_meantrainscore.append((sum(accuracy_trainscore)/i))
		accuracy_meantestscore.append((sum(accuracy_testscore)/i))
		accuracy_trainscore=[]
		accuracy_testscore=[]
	print()
	print("Naive Bayes Accuracy for training vs test set")
	for k in range(len(accuracy_meantrainscore)):
		print("After"+" "+str(k+2)+ " "+"fold training set accuracy:"+str(accuracy_meantrainscore[k]))
		print("After"+" "+str(k+2)+" "+"fold test set accuracy:"+str(accuracy_meantestscore[k]))
	#print(accuracy_meantrainscore,accuracy_meantestscore)
	plt.plot(samples,accuracy_meantrainscore,'bo-',label='Train Accuracy')
	plt.plot(samples,accuracy_meantestscore,'ro-',label='Test Accuracy')
	plt.xticks(fontsize=10)
	plt.yticks(fontsize=10)
	plt.xlabel('K Value during Cross Fold',fontsize=15)
	plt.ylabel('Mean Accuracy',fontsize=15)
	plt.legend(fontsize=15)
	plt.title('K vs Train/Test Accuracy For Naive Bayes Classifier',fontsize=15)
	axes = plt.gca()
	axes.set_ylim([0.7,0.9])
	plt.show()
	#cv_results = cross_val_score(model, x, y, cv=10, scoring='accuracy')
	#print(cv_results)



def main():

	x,y = generate_data() #Generate data
	#print(x,y)
	y = flip_labels(y) #Flip labels
	y=np.asarray(y) #Change list to array
	train_test_dt(x,y)
	train_test_nb(x,y)


if __name__=='__main__':
	main()
